package com.atguigu06.polymorphism;

/**
 * ClassName: Person
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 16:20
 * @Version 1.0
 */
public class Person {
    String name;
    int age;

    int id = 1001;

    public void eat(){
        System.out.println("人吃饭");
    }

    public void walk(){
        System.out.println("人走路");
    }
}
