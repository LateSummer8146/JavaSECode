package com.atguigu04.override;

/**
 * ClassName: AbstractTest1
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 15:02
 * @Version 1.0
 */
public abstract class AbstractTest1 {
//    private abstract void method();

//    public static abstract void method();
}
