package com.atguigu04.override;

/**
 * ClassName: OverrideTest
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 10:35
 * @Version 1.0
 */
public class OverrideTest {
    public static void main(String[] args) {

        Student s1 = new Student();

        s1.eat();
        s1.sleep();


    }
}
