package com.atguigu07.object;

/**
 * ClassName: Object
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 10:02
 * @Version 1.0
 */
//public class Object {
//}
