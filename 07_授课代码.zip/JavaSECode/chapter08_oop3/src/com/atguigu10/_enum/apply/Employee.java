package com.atguigu10._enum.apply;

/**
 * @author shkstart
 * @create 11:20
 */
public class Employee {

}
