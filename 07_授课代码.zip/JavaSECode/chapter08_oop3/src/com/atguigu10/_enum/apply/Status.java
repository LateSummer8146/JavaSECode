package com.atguigu10._enum.apply;

/**
 * 定义公司中员工的状态
 *
 * @author shkstart
 * @create 11:18
 */
public enum Status {



}
