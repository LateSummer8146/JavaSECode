package com.atguigu11.annotation.juint;

/**
 *
 * @author shkstart
 * @create 14:34
 */
public class JUnitTest {



}
