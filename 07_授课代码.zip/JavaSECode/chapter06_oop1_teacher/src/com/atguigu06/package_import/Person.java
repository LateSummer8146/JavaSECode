package com.atguigu06.package_import;

/**
 * ClassName: Person
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 11:39
 * @Version 1.0
 */
public class Person {

}
