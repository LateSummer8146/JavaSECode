package com.atguigu04.example.exer2;

/**
 * ClassName: Exer02Test
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 11:54
 * @Version 1.0
 */
public class Exer02Test {
    public static void main(String[] args) {

        //创建Exer02的对象
        Exer02 exer = new Exer02();
//        exer.method1();

//        int area = exer.method2();
//        System.out.println("面积为：" + area);

        int area1 = exer.method3(3,8);
        System.out.println("面积为：" + area1);


    }
}
