package com.atguigu03.field_method.field.exer2;

/**
 * ClassName: MyDate
 * Description:
 *      声明一个MyDate类型，有属性：年year，月month，日day
 * @Author 尚硅谷-宋红康
 * @Create 9:03
 * @Version 1.0
 */
public class MyDate {

    int year; //年
    int month; //月
    int day; //日


}
