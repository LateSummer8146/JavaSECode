package com.atguigu02.memory;

/**
 * @author 尚硅谷-宋红康
 * @create 14:31
 */

public class Person {

}
