package com.atguigu07._abstract;

/**
 * ClassName: AbstractTest
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 14:34
 * @Version 1.0
 */
public class AbstractTest {
    public static void main(String[] args) {

//        Person p1 = new Person();
//        p1.eat();

        Student s1 = new Student();
        s1.eat();

//        Worker w1 = new Worker();


    }
}
