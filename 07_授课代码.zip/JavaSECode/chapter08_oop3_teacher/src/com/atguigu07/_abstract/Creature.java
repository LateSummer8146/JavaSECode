package com.atguigu07._abstract;

/**
 * ClassName: Creature
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 14:55
 * @Version 1.0
 */
public abstract class Creature { //生物类
    public abstract void breath();//呼吸
}
