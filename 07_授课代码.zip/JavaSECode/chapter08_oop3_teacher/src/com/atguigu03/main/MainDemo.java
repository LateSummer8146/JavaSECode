package com.atguigu03.main;

/**
 * ClassName: MainDemo
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 9:39
 * @Version 1.0
 */
public class MainDemo {
    public static void main(String[] args) {
        for (int i = 0; i < args.length; i++) {
            System.out.println("hello:" + args[i]);
        }
    }
}
