package com.atguigu08._interface.exer3;

/**
 * ClassName: IPower
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 9:18
 * @Version 1.0
 */
public interface IPower {
    void power();
}
