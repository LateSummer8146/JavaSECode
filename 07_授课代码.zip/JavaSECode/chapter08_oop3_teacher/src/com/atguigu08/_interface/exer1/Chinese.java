package com.atguigu08._interface.exer1;

/**
 * ClassName: Chinese
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 8:50
 * @Version 1.0
 */
public class Chinese implements Eatable{
    @Override
    public void eat() {
        System.out.println("中国人使用筷子吃饭");
    }
}
