package com.atguigu08._interface.exer1;

/**
 * ClassName: American
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 8:51
 * @Version 1.0
 */
public class American implements Eatable{
    @Override
    public void eat() {
        System.out.println("美国人使用刀叉吃饭");
    }
}
