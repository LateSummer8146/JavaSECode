package com.atguigu08._interface.exer1;

/**
 * ClassName: Eatable
 * Description:
 *      声明接口Eatable，包含抽象方法public abstract void eat();
 * @Author 尚硅谷-宋红康
 * @Create 8:49
 * @Version 1.0
 */
public interface Eatable {
    void eat();
}
