package com.atguigu08._interface.jdk8;

/**
 * ClassName: SuperClass
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 9:43
 * @Version 1.0
 */
public class SuperClass {

    public void method4(){
        System.out.println("SuperClass:深圳");
    }
}
