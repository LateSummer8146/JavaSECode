package com.atguigu08._interface.jdk8;

/**
 * ClassName: CompareB
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 9:39
 * @Version 1.0
 */
public interface CompareB {
    public default void method3(){
        System.out.println("CompareB:广州");
    }
}
