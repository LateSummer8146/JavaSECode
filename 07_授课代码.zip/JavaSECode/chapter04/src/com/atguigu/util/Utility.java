package com.atguigu.util;

/**
 * ClassName: Utility
 * Description:
 *
 * @Author 尚硅谷-宋红康
 * @Create 2022/11/15 15:46
 * @Version 1.0
 */
public class Utility {
}
