package com.atguigu2.two;

/*
 * 二维数组的基本使用（难点） （承接TwoArrayTest.java）
 * 
 *  @author 尚硅谷-宋红康
 *  @create 13:18
 * 
 */

public class TwoArrayTest1 {
	public static void main(String[] args) {

		//5. 数组元素的默认初始化值


		//6. 数组的内存解析


	}
}
