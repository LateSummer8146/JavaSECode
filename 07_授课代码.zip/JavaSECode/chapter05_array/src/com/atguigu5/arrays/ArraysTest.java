package com.atguigu5.arrays;

/**
 * 
 * 测试数组的工具类：Arrays的使用 （了解）
 *
 * @author 尚硅谷-宋红康
 * @create 13:20
 */
public class ArraysTest {
	public static void main(String[] args) {
		//1. boolean equals(int[] a,int[] b)：比较两个数组的元素是否依次相等


		//2. String toString(int[] a):输出数组元素信息。



		//3.void fill(int[] a,int val):将指定值填充到数组之中。


		//4. void sort(int[] a):使用快速排序算法实现的排序



		//5. int binarySearch(int[] a,int key):二分查找
		//使用前提：当前数组必须是有序的



	}
}
