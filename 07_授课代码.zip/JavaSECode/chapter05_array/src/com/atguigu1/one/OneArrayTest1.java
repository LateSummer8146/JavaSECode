package com.atguigu1.one;

/**
 * 一维数组的基本使用(承接OneArrayTest.java)
 *
 * @author 尚硅谷-宋红康
 * @create 12:18
 */
public class OneArrayTest1 {

    public static void main(String[] args) {
        //5. 数组元素的默认初始化值


        //6. 数组的内存解析


    }
}
