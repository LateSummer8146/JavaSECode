package com.atguigu07.object.tostring;

/**
 * @author 尚硅谷-宋红康
 * @create 1:04
 */
public class ToStringTest {
}
